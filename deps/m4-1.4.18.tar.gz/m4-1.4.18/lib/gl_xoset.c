#include <config.h>
#define GL_XOSET_INLINE _GL_EXTERN_INLINE
#include "gl_xoset.h"
