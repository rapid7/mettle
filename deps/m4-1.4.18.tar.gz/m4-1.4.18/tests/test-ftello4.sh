#!/bin/sh

./test-ftello4${EXEEXT} "$srcdir/test-ftello4.sh" || exit 1

exit 0
